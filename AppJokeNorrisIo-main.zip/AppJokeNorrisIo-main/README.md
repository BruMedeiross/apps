# AppJokeNorisIo
<b> Arquitetura MVP</B><br>

<br>
Requisição via API: https://api.chucknorris.io/
